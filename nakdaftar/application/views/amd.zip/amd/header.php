<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title> <?php echo $title ?></title>    
        <!-- Plugins CSS -->

        <meta name="keywords" content="byond success, guru pengurusan bisnes, abdul basit" />
        <meta name="description" content=" ">
        <meta name="author" content="Alif Azuwan">

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.jpg" type="image/x-icon" />
        <link rel="apple-touch-icon" href="<?php echo base_url()?>assets/<?php echo base_url()?>assets/img/apple-touch-icon.png">
        <link href="<?php echo base_url()?>assets/css/plugins/plugins.css" rel="stylesheet">
        <link href="<?php echo base_url()?>assets/linearicons/fonts.css" rel="stylesheet">
        <link href="<?php echo base_url()?>assets/css/style.css" rel="stylesheet">
    </head>