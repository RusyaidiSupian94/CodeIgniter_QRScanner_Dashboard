<table>
<tbody>
<th>
<td>NAMA</td>
<td>JAWATAN</td>
</th>
<tr>
<td>Penasihat Tetap</td>
<td>Dato’ Dr. Fadzilah Kamsah</td>
</tr>
<tr>
<td>Penasihat</td>
<td>Dr. Muhd. Uthman el-Muhammady</td>
</tr>
<tr>
<td>Presiden</td>
<td>Dr. Tengku Asmadi bin Tengku Mohamad</td>
</tr>
<tr>
<td>Timbalan Presiden</td>
<td>Dr. Danial Zainal Abidin</td>
</tr>
<tr>
<td>Naib Presiden 1</td>
<td>Ustaz Zamri Zainal Abidin el-Azhari</td>
</tr>
<tr>
<td>Naib Presiden 2</td>
<td>Dr. Sharifah Hayaati binti Syed Ismail</td>
</tr>
<tr>
<td>Setiausaha Kehormat</td>
<td>Tn. Hj. Ahmad Fadzli Yusof</td>
</tr>
<tr>
<td>Bendahari Kehormat</td>
<td>Encik Osman bin Affan</td>
</tr>
</tbody>

</table>