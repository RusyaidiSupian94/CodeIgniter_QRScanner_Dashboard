<!--back to top-->
        <a href="#" class="back-to-top" id="back-to-top"><i class="icon-chevron-up"></i></a>
        <!-- jQuery first, then Tether, then Bootstrap JS. -->
        <script type="text/javascript" src="<?php echo base_url()?>assets/js/plugins/plugins.js"></script> 
        <!--tweet-scroller-->
        <script src="<?php echo base_url()?>assets/tweetie/tweetie.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo base_url()?>assets/js/landing.custom.js"></script> 
    </body>
</html>
