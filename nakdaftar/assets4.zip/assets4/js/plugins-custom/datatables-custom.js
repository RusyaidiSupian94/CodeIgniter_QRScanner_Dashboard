$(document).ready(function() {
    $('#data-table').DataTable({responsive:true});
} );