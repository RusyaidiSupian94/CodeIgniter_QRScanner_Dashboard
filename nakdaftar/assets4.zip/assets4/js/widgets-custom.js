$(function () {
    "use strict";
    $(".bar").peity("bar", {
        fill: ["#0084ff", "#e7f3fe"],
        height:30,
        width:64
    });
     $(".bar2").peity("bar", {
        fill: ["#94df4a", "#e5fcd0"],
        height:30,
        width:64
    });
     $(".bar3").peity("bar", {
        fill: ["#fa625e", "#fee5e4"],
        height:30,
        width:64
    });
      $(".bar4").peity("bar", {
        fill: ["#86d4f5", "#f6f8fa"],
        height:30,
        width:64
    });
       $(".line").peity("line",{
        fill: '#e7f3fe',
        stroke:'#0084ff',
         height:30,
        width:64
    });
      $(".line2").peity("line",{
        fill: '#e5fcd0',
        stroke:'#94df4a',
         height:30,
        width:64
    });
        $(".line3").peity("line",{
        fill: '#fef8e2',
        stroke:'#f3d768',
         height:30,
        width:64
    });
      $(".line4").peity("line",{
        fill: '#d9fff8',
        stroke:'#2cddbe',
         height:30,
        width:64
    });
});